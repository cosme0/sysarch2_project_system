// Shared UI helpers: theme toggle, site-wide toasts, confirm modal,
// tabbed admin sections, responsive table labels, and scroll-to-top.
(function () {
    'use strict';

    var THEME_KEY = 'amdpms-theme';

    function onReady(fn) {
        if (document.readyState !== 'loading') { fn(); } else { document.addEventListener('DOMContentLoaded', fn); }
    }

    /* ---- Theme ---- */
    function currentTheme() {
        try { return localStorage.getItem(THEME_KEY) || 'light'; } catch (e) { return 'light'; }
    }

    function updateThemeUI() {
        var dark = currentTheme() === 'dark';
        document.querySelectorAll('.theme-toggle').forEach(function (btn) {
            btn.setAttribute('aria-pressed', String(dark));
            var icon = btn.querySelector('.theme-icon');
            if (icon) icon.textContent = dark ? '\u2600\uFE0F' : '\uD83C\uDF19';
        });
    }

    function toggleTheme() {
        try { localStorage.setItem(THEME_KEY, currentTheme() === 'dark' ? 'light' : 'dark'); } catch (e) {}
        document.documentElement.setAttribute('data-theme', currentTheme());
        updateThemeUI();
    }

    /* ---- Toast ---- */
    var toastTimer = null;

    function showToast(msg, type) {
        var el = document.getElementById('appToast');
        if (!el) {
            el = document.createElement('div');
            el.id = 'appToast';
            el.className = 'app-toast';
            (document.body || document.documentElement).appendChild(el);
        }
        el.textContent = msg;
        el.className = 'app-toast' + (type ? ' ' + type : '') + ' show';
        clearTimeout(toastTimer);
        toastTimer = setTimeout(function () {
            el.className = 'app-toast' + (type ? ' ' + type : '');
        }, 3200);
    }

    /* ---- Confirm modal ---- */
    var pendingForm = null;
    var pendingSubmitter = null;

    function openModal() {
        var overlay = document.getElementById('confirmModal');
        if (!overlay) return;
        overlay.classList.add('open');
        overlay.setAttribute('aria-hidden', 'false');
        var ok = document.getElementById('confirmOk');
        if (ok) ok.focus();
    }

    function closeModal() {
        var overlay = document.getElementById('confirmModal');
        if (!overlay) return;
        overlay.classList.remove('open');
        overlay.setAttribute('aria-hidden', 'true');
        pendingForm = null;
        pendingSubmitter = null;
    }

    function initConfirmModal() {
        var overlay = document.getElementById('confirmModal');
        var cancelBtn = document.getElementById('confirmCancel');
        var okBtn = document.getElementById('confirmOk');
        if (!overlay || !cancelBtn || !okBtn) return;

        document.addEventListener('submit', function (e) {
            var form = e.target;
            if (!form || form.tagName !== 'FORM') return;
            if (!form.hasAttribute('data-confirm') || form.getAttribute('data-confirmed') === '1') return;
            e.preventDefault();
            e.stopImmediatePropagation();
            pendingForm = form;
            pendingSubmitter = e.submitter || form.querySelector('input[type=submit], button[type=submit]');
            var text = document.getElementById('confirmText');
            if (text) text.textContent = form.getAttribute('data-confirm') || 'Are you sure?';
            openModal();
        }, true);

        cancelBtn.addEventListener('click', closeModal);
        okBtn.addEventListener('click', function () {
            closeModal();
            if (!pendingForm) return;
            var sub = pendingSubmitter;
            if (sub && sub.name) {
                var h = document.createElement('input');
                h.type = 'hidden';
                h.name = sub.name;
                h.value = sub.value || '';
                pendingForm.appendChild(h);
            }
            pendingForm.setAttribute('data-confirmed', '1');
            pendingForm.submit();
        });
        overlay.addEventListener('click', function (e) {
            if (e.target === overlay) closeModal();
        });
        document.addEventListener('keydown', function (e) {
            if (e.key === 'Escape' && document.getElementById('confirmModal').classList.contains('open')) closeModal();
        });
    }

    /* ---- Tabs ---- */
    function initTabs() {
        document.querySelectorAll('[data-tabs]').forEach(function (group) {
            var buttons = group.querySelectorAll('[data-tab-target]');
            var panels = document.querySelectorAll('[data-tab-panel]');
            buttons.forEach(function (btn) {
                btn.addEventListener('click', function () {
                    var target = btn.getAttribute('data-tab-target');
                    buttons.forEach(function (b) {
                        var active = b === btn;
                        b.classList.toggle('active', active);
                        b.setAttribute('aria-selected', String(active));
                    });
                    panels.forEach(function (p) {
                        p.classList.toggle('active', p.id === target);
                    });
                });
            });
        });
    }

    /* ---- Responsive table labels (auto from <th> text) ---- */
    function initTableLabels() {
        document.querySelectorAll('.admin-table').forEach(function (table) {
            var ths = Array.prototype.map.call(
                table.querySelectorAll('thead th'),
                function (th) { return th.textContent.trim(); }
            );
            table.querySelectorAll('tbody tr').forEach(function (tr) {
                tr.querySelectorAll('td').forEach(function (td, i) {
                    if (!td.getAttribute('data-label') && ths[i]) {
                        td.setAttribute('data-label', ths[i]);
                    }
                });
            });
        });
    }

    /* ---- Scroll to top ---- */
    function initScrollTop() {
        var btn = document.getElementById('scrollTop');
        if (!btn) {
            btn = document.createElement('button');
            btn.type = 'button';
            btn.id = 'scrollTop';
            btn.className = 'scroll-top';
            btn.setAttribute('aria-label', 'Back to top');
            btn.textContent = '\u2191';
            (document.body || document.documentElement).appendChild(btn);
        }
        btn.addEventListener('click', function () {
            window.scrollTo({ top: 0, behavior: 'smooth' });
        });
        function onScroll() {
            btn.classList.toggle('show', (window.pageYOffset || document.documentElement.scrollTop) > 420);
        }
        window.addEventListener('scroll', onScroll, { passive: true });
        onScroll();
    }

    /* ---- Preloader (hide once page resources finish) ---- */
    function ensurePreloader(text) {
        var pre = document.getElementById('preloader');
        if (!pre) {
            pre = document.createElement('div');
            pre.className = 'preloader';
            pre.id = 'preloader';
            pre.setAttribute('aria-hidden', 'true');
            pre.innerHTML = '<div class="preloader-pill" aria-hidden="true"></div>'
                + '<p class="preloader-text">Loading medications\u2026</p>';
            (document.body || document.documentElement).appendChild(pre);
        }
        var cap = pre.querySelector('.preloader-text');
        if (cap && text) cap.textContent = text;
        pre.classList.remove('hide');
        return pre;
    }

    function hidePreloader() {
        var pre = document.getElementById('preloader');
        if (!pre) return;
        pre.classList.add('hide');
        setTimeout(function () {
            if (pre.parentNode) pre.parentNode.removeChild(pre);
        }, 400);
    }

    window.APP_LOADER = {
        show: ensurePreloader,
        hide: hidePreloader
    };

    function initPreloader() {
        var pre = document.getElementById('preloader');
        if (!pre) return;
        function done() {
            if (!pre) return;
            pre.classList.add('hide');
            setTimeout(function () {
                if (pre.parentNode) pre.parentNode.removeChild(pre);
            }, 400);
        }
        if (document.readyState === 'complete') { done(); return; }
        window.addEventListener('load', done);
        setTimeout(done, 8000);
    }

    /* ---- Server-supplied toast (set via window.APP_TOAST) ---- */
    function initServerToast() {
        if (window.APP_TOAST && window.APP_TOAST.message) {
            showToast(window.APP_TOAST.message, window.APP_TOAST.type || 'success');
            delete window.APP_TOAST;
        }
    }

    onReady(function () {
        document.documentElement.setAttribute('data-theme', currentTheme());
        updateThemeUI();
        document.querySelectorAll('.theme-toggle').forEach(function (btn) {
            btn.addEventListener('click', toggleTheme);
        });
        initConfirmModal();
        initTabs();
        initTableLabels();
        initScrollTop();
        initPreloader();
        initServerToast();
    });
})();
