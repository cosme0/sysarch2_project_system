<?php
require_once __DIR__ . '/config.php'; // loaded before $pageTitle in parent scripts
$currentPage = basename($_SERVER['PHP_SELF']);
$pageTitle = $pageTitle ?? SYSTEM_NAME_FULL;
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= htmlspecialchars($pageTitle) ?></title>
<link rel="stylesheet" href="css/pharmacy.css?v=<?= filemtime(__DIR__ . '/../css/pharmacy.css') ?>">
<script>
(function(){try{var t=localStorage.getItem('amdpms-theme');if(t==='dark'){document.documentElement.setAttribute('data-theme','dark');}}catch(e){}})();
</script>
<?php if (!empty($includeCharts)): ?>
<script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.1/dist/chart.umd.min.js"></script>
<?php endif; ?>
</head>
<body>
    <div class="preloader" id="preloader" aria-hidden="true">
        <div class="preloader-pill" aria-hidden="true"></div>
        <p class="preloader-text">Loading medications&#8230;</p>
    </div>

    <div class="site-sticky">
    <header class="site-header">
        <?php include __DIR__ . '/brand-mark.php'; ?>

        <div class="menu-toggle" id="menu-toggle" aria-label="Toggle menu">
            <span></span><span></span><span></span>
        </div>

<div class="header-actions">
            <form class="search-bar" action="shop.php" method="get" role="search">
                <input type="text" name="q" id="sea" placeholder="Search medications, SKU, or batch…" value="<?= htmlspecialchars($_GET['q'] ?? '') ?>">
                <button type="submit" id="seab">Search</button>
            </form>
            <form method="post" class="user-bar">
                <span>Staff: <strong><?= htmlspecialchars($_SESSION['fname'] ?? 'User') ?></strong></span>
                <button type="button" class="theme-toggle" aria-label="Toggle color theme" aria-pressed="false"><span class="theme-icon" aria-hidden="true">🌙</span></button>
                <button type="submit" name="logout" class="btn-logout">Logout</button>
            </form>
        </div>
    </header>

    <nav class="site-nav" id="navbar">
        <a href="home.php" class="<?= $currentPage === 'home.php' ? 'active' : '' ?>">Dashboard</a>
        <?php if (isAdmin()): ?>
        <div class="nav-drop">
            <a href="admin.php" class="nav-drop-trigger <?= in_array($currentPage, ['admin.php', 'support-tickets.php', 'reports.php'], true) ? 'active' : '' ?>" aria-haspopup="true" aria-expanded="false">
                Admin
                <span class="nav-drop-burger" aria-hidden="true">☰</span>
            </a>
            <div class="nav-drop-menu" role="menu" aria-label="Admin submenu">
                <a href="support-tickets.php" role="menuitem" class="<?= $currentPage === 'support-tickets.php' ? 'active' : '' ?>">Tickets</a>
                <a href="reports.php" role="menuitem" class="<?= $currentPage === 'reports.php' ? 'active' : '' ?>">Reports</a>
            </div>
        </div>
        <?php else: ?>
        <a href="reports.php" class="<?= $currentPage === 'reports.php' ? 'active' : '' ?>">Reports</a>
        <?php endif; ?>
        <a href="shop.php" class="<?= $currentPage === 'shop.php' ? 'active' : '' ?>">Medications</a>
        <a href="contact.php" class="<?= $currentPage === 'contact.php' ? 'active' : '' ?>">Support</a>
        <a href="account.php" class="<?= $currentPage === 'account.php' ? 'active' : '' ?>">Account</a>
        <a href="about.php" class="<?= $currentPage === 'about.php' ? 'active' : '' ?>">About System</a>
    </nav>
    </div>

    <main>
