<?php

if (!defined('SMTP_HOST')) define('SMTP_HOST', 'smtp.gmail.com');
if (!defined('SMTP_PORT')) define('SMTP_PORT', 587); 
if (!defined('SMTP_SECURE')) define('SMTP_SECURE', 'tls'); 
if (!defined('SMTP_USERNAME')) define('SMTP_USERNAME', 'kenkevincabanalan0@gmail.com');// palitan ng email address na gagamitin sa pag send ng mga email
if (!defined('SMTP_PASSWORD')) define('SMTP_PASSWORD', 'ntvq zqhc vlyc zpqi');// sa gmail account need buksan and double authentication tapos gumawa ng app password para sa email na gagamitin sa pag send ng email
if (!defined('SMTP_FROM_EMAIL')) define('SMTP_FROM_EMAIL', 'kenkevincabanalan0@gmail.com');// palitan ng email address na gagamitin sa pag send ng mga email
if (!defined('SMTP_FROM_NAME')) define('SMTP_FROM_NAME', SYSTEM_NAME_FULL);

