<?php
include("auth.php");
include("database.php");
requireLogin();
include("includes/logout.php");
require_once __DIR__ . '/includes/config.php';

// Fetch Arduino / bridge status (best-effort; bridge may be offline).
$arduinoStatus = null;
$bridgeUp = @file_get_contents('http://localhost:3000/status', false, stream_context_create(['http' => ['timeout' => 2]]));
if ($bridgeUp !== false) {
    $decoded = json_decode($bridgeUp, true);
    if (is_array($decoded)) $arduinoStatus = $decoded;
}



$pageTitle = 'Dispensing Receipt | ' . SYSTEM_NAME_FULL;
include("includes/site-header.php");

$conn = mysqli_connect("localhost", "root", "", "db_users");

// If requested, show a recent receipt for the currently logged-in user.
$recent = isset($_GET['recent']) ? max(0, (int)$_GET['recent']) : 0;
$userEmail = $_SESSION['email'] ?? null;
if ($recent > 0 && $userEmail) {
    $stmt = $conn->prepare("SELECT medication_name, medication_sku, qty, dispensed_at FROM dispense_history WHERE user_email = ? ORDER BY dispensed_at DESC LIMIT ?");
    $stmt->bind_param("si", $userEmail, $recent);
    $stmt->execute();
    $res = $stmt->get_result();
    $rows = [];
    while ($r = $res->fetch_assoc()) $rows[] = $r;
    $conn->close();

    // Notify the dispenser (3 long buzzes) when the receipt is shown.
    if (count($rows) > 0) {
        @file_get_contents('http://localhost:3000/buzz', false, stream_context_create([
            'http' => ['timeout' => 2],
        ]));
    }

    $totalUnits = 0;
    foreach ($rows as $r) $totalUnits += (int)$r['qty'];
    $totalItems = count($rows);
    $refCode = $totalItems > 0
        ? 'REF-' . date('Ymd', strtotime($rows[0]['dispensed_at'])) . '-' . strtoupper(substr(md5($userEmail . $rows[0]['dispensed_at']), 0, 6))
        : '';
    ?>
<section class="receipt-page">
    <div class="receipt-card">
        <div class="receipt-head">
            <div class="receipt-check" aria-hidden="true">✓</div>
            <h1 class="receipt-title">Dispensing Complete</h1>
            <p class="receipt-sub">Items successfully dispensed from the automated system.</p>
        </div>

        <?php if ($totalItems > 0): ?>
            <div class="receipt-meta">
                <div class="receipt-meta-row">
                    <span>Dispensed by</span>
                    <strong><?= htmlspecialchars($userEmail) ?></strong>
                </div>
                <div class="receipt-meta-row">
                    <span>Date &amp; time</span>
                    <strong><?= htmlspecialchars(date('M j, Y — h:i A', strtotime($rows[0]['dispensed_at']))) ?></strong>
                </div>
                <div class="receipt-meta-row">
                    <span>Transaction</span>
                    <strong class="mono"><?= htmlspecialchars($refCode) ?></strong>
                </div>
            </div>

            <div class="receipt-items">
                <div class="receipt-items-head">
                    <span>Item</span>
                    <span>Qty</span>
                </div>
                <?php foreach ($rows as $i => $r): ?>
                <div class="receipt-item">
                    <span class="receipt-item-name"><?= ($i + 1) ?>. <?= htmlspecialchars($r['medication_name']) ?>
                        <small><?= htmlspecialchars($r['medication_sku']) ?></small>
                    </span>
                    <span class="receipt-item-qty">× <?= (int)$r['qty'] ?></span>
                </div>
                <?php endforeach; ?>
                <div class="receipt-summary">
                    <span><?= $totalItems ?> item<?= $totalItems === 1 ? '' : 's' ?></span>
                    <strong><?= $totalUnits ?> unit<?= $totalUnits === 1 ? '' : 's' ?> dispensed</strong>
                </div>
            </div>

            <p class="receipt-note">Automatically issued by <?= SYSTEM_ACRONYM ?>. Keep this receipt for your records.</p>

            <div class="receipt-actions">
                <button type="button" class="btn btn-primary" onclick="window.print()">
                    <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><polyline points="6 9 6 2 18 2 18 9"></polyline><path d="M6 18H4a2 2 0 0 1-2-2v-5a2 2 0 0 1 2-2h16a2 2 0 0 1 2 2v5a2 2 0 0 1-2 2h-2"></path><rect x="6" y="14" width="12" height="8"></rect></svg>
                    Print receipt
                </button>
                <a class="btn btn-outline" href="shop.php">Back to medications</a>
            </div>
        <?php else: ?>
            <div class="receipt-empty">
                <p class="receipt-empty-title">No recent records</p>
                <p>No dispense records were found for your account.</p>
                <a class="btn btn-primary" href="shop.php">Back to medications</a>
            </div>
        <?php endif; ?>
    </div>
</section>
<?php include("includes/site-footer.php"); ?>
    <?php
    exit;
}

// Search filter (from the header search bar or ?q=).
$searchTerm = trim($_GET['q'] ?? '');
if ($searchTerm !== '') {
    $like = '%' . $conn->real_escape_string($searchTerm) . '%';
    $stmt = $conn->prepare("SELECT * FROM medications WHERE name LIKE ? OR sku LIKE ? OR category LIKE ? ORDER BY channel ASC, id ASC");
    $stmt->bind_param("sss", $like, $like, $like);
    $stmt->execute();
    $medsResult = $stmt->get_result();
} else {
    $medsResult = $conn->query("SELECT * FROM medications ORDER BY channel ASC, id ASC");
}

$products = [];
while ($m = $medsResult->fetch_assoc()) {
    $products[] = [
        'name'   => $m['name'],
        'sku'    => $m['sku'],
        'stock'  => (int)$m['stock'],
        'unit'   => '₱' . number_format((float)$m['price'], 2),
        'tag'    => $m['category'],
        'status' => $m['stock'] > 0 ? ($m['stock'] < 20 ? 'low' : 'ok') : 'out',
        'icon'   => $m['icon'],
    ];
}
$conn->close();
?>
